#pragma once

#include "headers/OpenSanityGlobal.h"

class Action0x0BA {
	public:

		void Dispose(byte param_1);
		static void EmptyFunction();
		static int GetSize();
		virtual void ExecuteFromCallContext(int time_clock);
		void Construct();

};
