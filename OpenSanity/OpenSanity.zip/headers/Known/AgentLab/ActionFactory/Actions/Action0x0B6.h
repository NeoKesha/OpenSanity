#pragma once

#include "headers/OpenSanityGlobal.h"
#include "headers/Known/AgentLab/ActionFactory/Actions/ActionAbstract.h"

class Action0x0B6 : public ActionAbstract {
	public:

		void Dispose(byte param_1);
		static void EmptyFunction();
		static void ExecuteFromCallContext();
		static int GetSize();
		void Construct();

};
