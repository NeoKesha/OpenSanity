#pragma once

#include "headers/OpenSanityGlobal.h"

class MY_D3DXCOLOR {
	public:
		float R;
		float G;
		float B;
		float A;

		MY_D3DXCOLOR(MY_D3DXCOLOR* other);

};
