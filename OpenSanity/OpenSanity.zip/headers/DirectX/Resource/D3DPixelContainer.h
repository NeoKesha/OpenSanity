#pragma once

#include "headers/OpenSanityGlobal.h"
#include "headers/DirectX/Resource/D3DResource.h"

class D3DPixelContainer : public D3DResource {
	public:
		int format;
		int size;


};
