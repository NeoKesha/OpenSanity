#pragma once

#include "headers/OpenSanityGlobal.h"
#include "headers/DirectX/Resource/D3DPixelContainer.h"

class D3DBaseTexture : public D3DPixelContainer {
	public:


};
